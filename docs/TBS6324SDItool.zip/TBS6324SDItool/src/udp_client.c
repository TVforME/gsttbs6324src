#include <pthread.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if_arp.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <sys/syscall.h>
#include <assert.h> 
#include <netinet/tcp.h>

#include "cmd_udp_internal.h"

#include <stdint.h>
#include <inttypes.h>
#include <stdbool.h>
#include <ctype.h>
#include <netdb.h>
#include <getopt.h>
#include <linux/fs.h>

/* DVB Card Drivers */
#include "libdvbv5/dvb-dev.h"

int i_adapterEN = 0;
int i_adapterN = 0;
//int i_fenum =0;
int i_frontend=-1;
int i_version = 0;

int i_device_list = 0;

int i_information = 0;
int i_audiobitrateEN = 0;
int i_abNum = 0;
int i_audiotypeEN = 0;
int i_TSaudioEN = 0;
unsigned char *str_audiotype = 0;
int i_TSaudio = 0;
int i_audioResampleEN = 0;
int i_aResampleNum = 0;
int i_TSbufferEN = 0;
int i_TSbufferNum = 0;
int i_audiochannelEN = 0;
int i_audiochannelNum = 0;

int i_audioinputEN = 0;
int i_audioinputNum = 0;
unsigned char *str_audioinputNum = 0;

int i_cfg = 0;
int i_softwareRST = 0;
int i_hardwareRST = 0;
int i_system_update = 0;

int i_profileEN = 0;
int i_profileNum = 0;

int i_bitrateEN = 0;
int i_bitrateNum = 0;

int i_codecTypeEN = 0;
unsigned char *str_codecType = 0;

int i_bitrateMaxEN = 0;
unsigned char *str_bitrateMaxNum = 0;

int i_GopkeyEN = 0;
int i_GopkeyNum = 0;

int i_minqpEN = 0;
int i_minqpNum = 0;

int i_maxqpEN = 0;
int i_maxqpNum = 0;

int i_serviceIdEN = 0;
int i_serviceId = 0;
int i_nullPacketEnableEN = 0;
int i_nullPacketNum = 0;

unsigned char *str_widthNum = NULL;
int  i_widthEN = 0;
int  i_heightEN = 0;
int  i_sizeEN = 0;
int  i_sizeNum = 0;

unsigned char *str_heightNum = NULL;
int i_fpsEN = 0;
int i_fpsNum = 0;

int i_prognameEN = 0;
unsigned char *str_progname = NULL;


int i_encodeModeEN = 0;
unsigned char *str_encodeMode = NULL;

int i_pidEN = 0;
int i_pidNum = 0;

int i_FPGA_EN=0;

int i_logo_update = 0;

int i_logoEN = 0;
int i_logoenableNum = 0;

int i_logoAlphaEN = 0;
int i_logoAlphaNum = 0;

int i_logoXEN = 0;
int i_logoXNum = 0;

int i_logoYEN = 0;
int i_logoYNum = 0;

int i_txtEN = 0;
int i_txtenableNum = 0;

int i_txtXEN = 0;
int i_txtYEN = 0;

int i_txtAlphaEN = 0;
int i_txtAlphaNum = 0;
int i_txtcolorEN = 0;
int i_txtSizeEN = 0;
int i_txtSizeNum = 0;
int i_txtStrEN = 0;


int inforn = 0;
hardinfor hf[128];
u32 typeId = 0;
int devnum = 0;

#define MAX_BUFFER_SIZE 2048

#define MAX_PACKET_LEN  960

#define CMD_ERROR       0x10203020

#define GET_STREAM1     0x10203030
#define GET_STREAM2     0x10203031
#define GET_OSD1        0x10203032
#define GET_OSD2        0x10203033
#define GET_EXT         0x10203034

#define SET_STREAM1     0x10203040
#define SET_STREAM2     0x10203041
#define SET_OSD1        0x10203042
#define SET_OSD2        0x10203043
#define SET_EXT         0x10203044
#define SET_REBOOT      0x10203045
#define SET_RESET       0x10203046
#define SET_DELRECFILE  0x10203047

#define UPLOAD_FIMWARE  0x10203050
#define UPLOAD_BMP1     0x10203051
#define UPLOAD_BMP2     0x10203052

#define CHECK_FILE_OK 	0x10203060
#define CHECK_FILE_BAD 	0x10203060

pthread_t th;

/** Compare libdvbv5 devices to sort them */
static int
cmpDvbDev(const void *p1, const void *p2)
{
    const struct dvb_dev_list *dev1 = p1;
    const struct dvb_dev_list *dev2 = p2;
    int a1, a2, r;

    // Extract the adapter number
    r = sscanf(dev1->path, "/dev/dvb/adapter%d/", &a1);
    if(r <= 0) {
        fprintf(stderr, "Scan of '%s' failed %d\n", dev1->path, r);
        return 0;
    }
    r = sscanf(dev2->path, "/dev/dvb/adapter%d/", &a2);
    if(r <= 0) {
        fprintf(stderr, "Scan of '%s' failed %d\n", dev2->path, r);
        return 0;
    }

    // Compare adapter numbers
    if(a1 != a2) {
        return a1 - a2;
    }

    // Same adapter - sort by device type (represents frontend, dmux etc.)
    if(dev1->dvb_type != dev2->dvb_type) {
        return (dev1->dvb_type - dev2->dvb_type);
    }

    // A complete solution would sort by device number as well (e.g. frontend0 before frontend1)
    // but these cards only ever have 0
    return 0;
}

void getHardwareInfor()
{

    struct dvb_device *dvb;
    struct dvb_dev_list *dvb_dev;
    struct dvb_v5_fe_parms *parms;
    int i = 0;
    int j = 0;
    int k = 0;
    int w = 0;

    int TBSid[2] = {0};
    dvb = dvb_dev_alloc();
    if (!dvb)
        return;
    dvb_dev_find(dvb,NULL,NULL);
    parms = dvb->fe_parms;
    dvb_dev = dvb->devices;

    // It seems that dvb_dev_find() returns the devices in arbitrary order - sort them
    qsort(dvb_dev, dvb->num_devices, sizeof(struct dvb_dev_list), cmpDvbDev);

    
    //printf("dvb->num_devices: %d\n", dvb->num_devices);
    //for(i = 0;i < dvb->num_devices;i++ ){
    //    printf("%2d: %s %d %s\n", i, dvb_dev[i].bus_id, dvb_dev[i].dvb_type, dvb_dev[i].path); 
    //}
  

    for(i = 0;i < dvb->num_devices;i++ ){
        if(dvb_dev[i].dvb_type != DVB_DEVICE_FRONTEND)
            continue;

        sscanf(dvb_dev[i].bus_id,"%x:%x",&TBSid[0],&TBSid[1]);
        sscanf(dvb_dev[i].path,"/dev/dvb/adapter%d/frontend%d", \
                &hf[i].adapter_i,&hf[i].frontend_i);

        // hf[i].adapter_i = i; // when adapter8--11,there is incorrect sequence on "path",correct it here.
        *(u32 *)hf[i].chipid = TBSid[1];//chipid
	*(u32 *)hf[i].chip2id = TBSid[0];//chipid
	//6308x,6304t,6304x,6302x,6302t60,6301t
        if((0x6304 == *(u32 *)hf[i].chipid)&&(0x0010 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = k;
		hf[i].devname = "TBS6304X";
            hf[inforn] = hf[i];
            inforn++;
            k++;
            if(k == 4){
                k = 0;
            }
        }else if((0x6308 == *(u32 *)hf[i].chipid)&&(0x0010 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = k;
		hf[i].devname = "TBS6308X";
            hf[inforn] = hf[i];
            inforn++;
            k++;
            if(k == 8){
                k = 0;
            }
        }else if((0x6312 == *(u32 *)hf[i].chipid)&&(0x0010 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = k;
		hf[i].devname = "TBS6312X";
            hf[inforn] = hf[i];
            inforn++;
            k++;
            if(k == 12){
                k = 0;
            }
        }else if((0x6304 == *(u32 *)hf[i].chipid)&&(0x0009 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = k;
		hf[i].devname = "TBS6304T";
            hf[inforn] = hf[i];
            inforn++;
            k++;
            if(k == 4){
                k = 0;
            }
	}else if((0x6324 == *(u32 *)hf[i].chipid)&&(0x0010 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = k;
		hf[i].devname = "TBS6324";
            hf[inforn] = hf[i];
            inforn++;
            k++;
            if(k == 4){
                k = 0;
            }
         }else if((0x6322 == *(u32 *)hf[i].chipid)&&(0x0010 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = j;
	    hf[i].devname = "TBS6322";
            hf[inforn] = hf[i];
            inforn++;
            j++;
            if(j == 2){
                j = 0;
            }
        }else if((0x6302 == *(u32 *)hf[i].chipid)&&(0x0010 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = j;
	    hf[i].devname = "TBS6302X";
            hf[inforn] = hf[i];
            inforn++;
            j++;
            if(j == 2){
                j = 0;
            }
        } else if((0x6302 == *(u32 *)hf[i].chipid)&&(0x0009 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = w;
	    hf[i].devname = "TBS6302T";
            hf[inforn] = hf[i];
            inforn++;
            w++;
            if(w == 2){
                w = 0;
            }
        }   else if((0x6301 == *(u32 *)hf[i].chipid)&&(0x0004 == *(u32 *)hf[i].chip2id)){
            hf[i].hdmi_index = 0;
		hf[i].devname = "TBS6301T";
            hf[inforn] = hf[i];
            inforn++;
        }else{
            // printf("id:%#08x\n",*(u32 *)hf[i].chipid);
        }
    }
    dvb_dev_free(dvb);
}


void wrReg32(u8 address,u32 data)
{
	struct mcu24cxx_info winfo;
	winfo.bassaddr = BASE_ADDRESS_UDPCMD; 

	switch(typeId)
	{
		case TBS6302X_1:
		case TBS6304X_1:
		case TBS6308X_1:
		case TBS6312X_1:
		case TBS6324_1:	
		case TBS6322_1:		
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1000; 
			break;
		case TBS6304X_2:
		case TBS6308X_2:
		case TBS6312X_2:
		case TBS6324_2:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x800; 
			break;
		case TBS6304X_3:
		case TBS6308X_3:
		case TBS6312X_3:
		case TBS6324_3:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1800; 
			break;
		case TBS6308X_4:
		case TBS6312X_4:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x400; 
			break;
		case TBS6308X_5:
		case TBS6312X_5:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1400; 
			break;
		case TBS6308X_6:
		case TBS6312X_6:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0xc00; 
			break;
		case TBS6308X_7:
		case TBS6312X_7:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1c00; 
			break;
		case TBS6312X_8:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x200; 
			break;
		case TBS6312X_9:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1200; 
			break;
		case TBS6312X_10:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0xa00; 
			break;
		case TBS6312X_11:
			winfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1a00; 
			break;
		default:
			break;
	}

	winfo.reg=address;
	winfo.data=data;
	//printf("data=0x%x\n",data);
	if( ioctl( i_frontend, FE_24CXX_WRITE, &winfo ) < 0 )	
	{
		//printf("write eror %s\n ",strerror(errno));
		//exit(1);
	}

}


u32 rdBuf32(u8 address)
{
	struct mcu24cxx_info rinfo;
	rinfo.bassaddr = BASE_ADDRESS_UDPCMD; 

	switch(typeId)
	{
		case TBS6302X_1:
		case TBS6304X_1:
		case TBS6308X_1:
		case TBS6312X_1:
		case TBS6324_1:
		case TBS6322_1:	
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1000; 
			break;
		case TBS6304X_2:
		case TBS6308X_2:
		case TBS6312X_2:
		case TBS6324_2:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x800; 
			break;
		case TBS6304X_3:
		case TBS6308X_3:
		case TBS6312X_3:
		case TBS6324_3:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1800; 
			break;
		case TBS6308X_4:
		case TBS6312X_4:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x400; 
			break;
		case TBS6308X_5:
		case TBS6312X_5:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1400; 
			break;
		case TBS6308X_6:
		case TBS6312X_6:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0xc00; 
			break;
		case TBS6308X_7:
		case TBS6312X_7:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1c00; 
			break;
		case TBS6312X_8:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x200; 
			break;
		case TBS6312X_9:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1200; 
			break;
		case TBS6312X_10:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0xa00; 
			break;
		case TBS6312X_11:
			rinfo.bassaddr = BASE_ADDRESS_UDPCMD + 0x1a00; 
			break;
		default:
			break;
	}
	rinfo.reg = address;
//printf("read base address =0x%x, reg:0x%x\n",rinfo.bassaddr,rinfo.reg);
	if( ioctl( i_frontend, FE_24CXX_READ, &rinfo ) < 0 )		
	{
		//printf("read eror ");
		//exit(1);
	}
	//printf("read data=0x%x\n",rinfo.data);
	return rinfo.data;
}

int check_status_ack()
{
		unsigned char tmpbuf[4]={0};
		int i =0;
		int time_max = 1000;

		for(i=0;i<time_max;i++)
		{
			*(u32 *)&tmpbuf[0] = rdBuf32(STATUS );
			if((tmpbuf[2]&0x80) == 0x80)
				break;

			usleep(1000);

		}
		if(i==time_max)
		{
			printf(" \nack time out :%x,%x,%x,%x\n\n",tmpbuf[0],tmpbuf[1],tmpbuf[2],tmpbuf[3]);
			return 0;
		}

		return 1;
}

int check_status_done()
{
		unsigned char tmpbuf[4]={0};
		int i =0;
		int time_max = 10000;
		for(i=0;i<time_max;i++)
		{
			*(u32 *)&tmpbuf[0] = rdBuf32(STATUS );
			if((tmpbuf[0]&0x01) == 0x01)
				break;
			usleep(5000);
		}
		if(i==time_max)
		{
			printf(" done time out \n\r");
			return 0;
		}
		return 1;

}


void check_status_free()
{
		unsigned char tmpbuf[4]={0};
		int i =0;
		int time_max = 1000;
		
		for(i=0;i<time_max;i++)
		{
			*(u32 *)&tmpbuf[0] = rdBuf32(STATUS );
			if((tmpbuf[0]&0x80) == 0x80)
				break;
			usleep(500);
		}
		if(i==time_max)
		{
			printf(" the device is busy\n\r");
		}
}

void gpio_wt(u8 address,u32 data)
{
	struct mcu24cxx_info winfo;
	winfo.bassaddr = 0x0000; 
	winfo.reg=address;
	winfo.data=data;
	//printf("data=0x%x\n",data);
	if( ioctl( i_frontend, FE_24CXX_WRITE, &winfo ) < 0 )	
	{
		//printf("write eror %s\n ",strerror(errno));
		//exit(1);
	}

}


u32 gpio_rd(u8 address)
{
	struct mcu24cxx_info rinfo;
	rinfo.bassaddr = 0x0000; 
	rinfo.reg = address;

	if( ioctl( i_frontend, FE_24CXX_READ, &rinfo ) < 0 )		
	{
		//printf("read eror ");
		//exit(1);
	}
	//printf("read data=0x%x\n",rinfo.data);
	return rinfo.data;
}

void reboot()
{

	unsigned char tmpbuf[4];
	u8 reboot_addr = 0x28;

	switch(typeId)
	{
		case TBS6302X_1:
		case TBS6304X_1:
		case TBS6308X_1:
		case TBS6312X_1:
		case TBS6324_1:
		case TBS6322_1:	
			reboot_addr = 0x2c;
			break;
		case TBS6304X_2:
		case TBS6308X_2:
		case TBS6312X_2:
		case TBS6324_2:
			reboot_addr = 0x44;
			break;
		case TBS6304X_3:
		case TBS6308X_3:
		case TBS6312X_3:
		case TBS6324_3:
			reboot_addr = 0x48;
			break;
		case TBS6308X_4:
		case TBS6312X_4:
			reboot_addr = 0x54;
			break;
		case TBS6308X_5:
		case TBS6312X_5:
			reboot_addr = 0x58;
			break;
		case TBS6308X_6:
		case TBS6312X_6:
			reboot_addr = 0x64;
			break;
		case TBS6308X_7:
		case TBS6312X_7:
			reboot_addr = 0x68;
			break;
		case TBS6312X_8:
			reboot_addr = 0x74;
			break;
		case TBS6312X_9:
			reboot_addr = 0x78;
			break;
		case TBS6312X_10:
			reboot_addr = 0x84;
			break;
		case TBS6312X_11:
			reboot_addr = 0x88;
			break;
		default:
			break;
	}

	tmpbuf[0]=0xff;
	tmpbuf[1]=0xff;
	tmpbuf[2]=0xff;
	tmpbuf[3]=0xff;
	gpio_wt(reboot_addr,*(u32 *)tmpbuf);	
	usleep(500);

	tmpbuf[0]=0;
	tmpbuf[1]=0;
	tmpbuf[2]=0;
	tmpbuf[3]=0;
	gpio_wt(reboot_addr,*(u32 *)tmpbuf);
	usleep(1000);

}

void reset()
{

	unsigned char tmpbuf[4];
	u8 reset_addr = 0x30;

	switch(typeId)
	{
		case TBS6302X_1:
		case TBS6304X_1:
		case TBS6308X_1:
		case TBS6312X_1:
		case TBS6324_1:
		case TBS6322_1:	
			reset_addr = 0x34;
			break;
		case TBS6304X_2:
		case TBS6308X_2:
		case TBS6312X_2:
		case TBS6324_2:
			reset_addr = 0x4c;
			break;
		case TBS6304X_3:
		case TBS6308X_3:
		case TBS6312X_3:
		case TBS6324_3:
			reset_addr = 0x50;
			break;
		case TBS6308X_4:
		case TBS6312X_4:
			reset_addr = 0x5c;
			break;
		case TBS6308X_5:
		case TBS6312X_5:
			reset_addr = 0x60;
			break;
		case TBS6308X_6:
		case TBS6312X_6:
			reset_addr = 0x6c;
			break;
		case TBS6308X_7:
		case TBS6312X_7:
			reset_addr = 0x70;
			break;
		case TBS6312X_8:
			reset_addr = 0x7c;
			break;
		case TBS6312X_9:
			reset_addr = 0x80;
			break;
		case TBS6312X_10:
			reset_addr = 0x8c;
			break;
		case TBS6312X_11:
			reset_addr = 0x90;
			break;
		default:
			break;
	}

	tmpbuf[0]=0xff;
	tmpbuf[1]=0xff;
	tmpbuf[2]=0xff;
	tmpbuf[3]=0xff;
	gpio_wt(reset_addr,*(u32 *)tmpbuf);	
	sleep(10);

	tmpbuf[0]=0;
	tmpbuf[1]=0;
	tmpbuf[2]=0;
	tmpbuf[3]=0;
	gpio_wt(reset_addr,*(u32 *)tmpbuf);
	usleep(1000);

}

int get_param(char *inputbuf,char *param,char *output)
{
	char a[32]={0},b[32]={0};
	char *temp=strstr(inputbuf,param);
	if(temp)
	{
		//printf("====temp=======\n%s\n",temp-1);
		char a[128]={0},b[128]={0};
		sscanf(temp,"%[^>]%[^<]",a,b);
		memcpy(output,&b[1],strlen(b)-1);
		//printf("a=%s,output=%s,b=%s\n",a,output,b);
		return 0;//sucess;
	}

	return -1;//fail
}

int packet_param_cmd_string(int cmd,char *param,int len,char *str)
{
        int offset=0;

        str[offset++]=cmd&0xff;
        str[offset++]=(cmd>>8)&0xff;
        str[offset++]=(cmd>>16)&0xff;
        str[offset++]=(cmd>>24)&0xff;
        str[offset++]=len&0xff;
        str[offset++]=(len>>8)&0xff;
        str[offset++]=(len>>16)&0xff;
        str[offset++]=(len>>24)&0xff;

	memcpy(&str[offset],param,len);

        return offset+len;
}

int add_param_package_string(char *param,char *string,char *out_string)
{
        sprintf(out_string,"&%s=%s",param,string);
        return strlen(out_string);
}


//read type, len, data, then command to send out
int udp_read( int type, unsigned char* data, unsigned short len)
{
	unsigned char tmpbuf[4]={0};
	int i;
	int udplen = 8;
	tmpbuf[3] = (type & 0xff000000)>>24; 
	tmpbuf[2] = (type & 0xff0000)>>16;
	tmpbuf[1] = (type & 0xff00)>>8;
	tmpbuf[0] = (type & 0xff);
	wrReg32((  RW_TYPEADDR),*(u32 *)&tmpbuf[0]);

	tmpbuf[3] = (udplen & 0xff000000)>>24; 
	tmpbuf[2] = (udplen & 0xff0000)>>16;
	tmpbuf[1] = (udplen & 0xff00)>>8;
	tmpbuf[0] = (udplen & 0xff);
	wrReg32((  RW_LENADDR),*(u32 *)&tmpbuf[0]);

	//command
	tmpbuf[0] = 0x80; //read
	tmpbuf[1] = 0x00; 
	tmpbuf[2] = 0x00;	
	tmpbuf[3] = 0x00;
	wrReg32((COMMAND),*(u32 *)&tmpbuf[0]);
	
	if(!check_status_ack())
		return 0;

	tmpbuf[0] = 0x80; //bit31 write 1
	wrReg32(( DATA_BLKCTRL),*(u32 *)&tmpbuf[0]);

	*(u32 *)&tmpbuf[0]  = rdBuf32(RW_TYPEADDR);
	*(u32 *)&tmpbuf[0]  = rdBuf32(RW_LENADDR);
	len = tmpbuf[1]*256+tmpbuf[0] - 8;

	if(len>1024)
		len = 1024;

	for(i=0;i<(len/4);i++)
	{
		*(u32 *)&data[i*4] = rdBuf32( RW_DATA);
	}
	if(len%4)
		*(u32 *)&data[i*4] = rdBuf32( RW_DATA);

	if(len<10)
		data[len] = '\0';
	else	
		data[len-1] = '\0';

	tmpbuf[0] = 0x00; // when finish the read , set clear (bit31)to 0
	wrReg32((DATA_BLKCTRL),*(u32 *)&tmpbuf[0]);

	return 1;
}
//write type, len, data, then command to send out
int update_write( int type, unsigned char* data, unsigned short len, int filelen)
{
	unsigned char tmpbuf[4]={0};
	int i;

	tmpbuf[0] = 0x80; //bit31 write 1
	wrReg32(( DATA_BLKCTRL),*(u32 *)&tmpbuf[0]);
	
	tmpbuf[3] = (type & 0xff000000)>>24; 
	tmpbuf[2] = (type & 0xff0000)>>16;
	tmpbuf[1] = (type & 0xff00)>>8 ;
	tmpbuf[0] = (type & 0xff);
	wrReg32((  RW_TYPEADDR),*(u32 *)&tmpbuf[0]);

	tmpbuf[3] = (filelen & 0xff000000)>>24; 
	tmpbuf[2] = (filelen & 0xff0000)>>16;
	tmpbuf[1] = (filelen & 0xff00)>>8 ;
	tmpbuf[0] = (filelen & 0xff);
	wrReg32((  RW_LENADDR),*(u32 *)&tmpbuf[0]);

	//write to fpga
	printf("write file len=%d\n",len);
	tmpbuf[0] = ((len & 0xff00)>>8) ;
	tmpbuf[1] = (len & 0xff);
	wrReg32(( RW_SIZEADDR ),*(u32 *)&tmpbuf[0]);

	for(i=0;i<(len/4);i++)
	{
		wrReg32(( RW_DATA),*(u32 *)&data[i*4]);
	}
	if(len%4)
		wrReg32(( RW_DATA),*(u32 *)&data[i*4]);

	//command
	tmpbuf[0] = 0x00; 
	tmpbuf[1] = 0x00; 
	tmpbuf[2] = 0x00;	
	tmpbuf[3] = 0x00;
	wrReg32((COMMAND),*(u32 *)&tmpbuf[0]);
	
	tmpbuf[0] = 0x00; // when finish the write , set clear (bit31)to 0
	wrReg32((DATA_BLKCTRL),*(u32 *)&tmpbuf[0]);

	return 1;
}

//write type, len, data, then command to send out
int udp_write( int type, unsigned char* data, unsigned short len)
{
	unsigned char tmpbuf[4]={0};
	int i;

	tmpbuf[0] = 0x80; //bit31 write 1
	wrReg32(( DATA_BLKCTRL),*(u32 *)&tmpbuf[0]);
	
	tmpbuf[3] = (type & 0xff000000)>>24; 
	tmpbuf[2] = (type & 0xff0000)>>16;
	tmpbuf[1] = (type & 0xff00)>>8 ;
	tmpbuf[0] = (type & 0xff);
	wrReg32((  RW_TYPEADDR),*(u32 *)&tmpbuf[0]);
	
	int udplen = len+8;
	tmpbuf[3] = (udplen & 0xff000000)>>24; 
	tmpbuf[2] = (udplen & 0xff0000)>>16;
	tmpbuf[1] = (udplen & 0xff00)>>8 ;
	tmpbuf[0] = (udplen & 0xff);
	wrReg32((  RW_LENADDR),*(u32 *)&tmpbuf[0]);

	//write to fpga
	tmpbuf[0] = ((len & 0xff00)>>8) ;
	tmpbuf[1] = (len & 0xff);
	wrReg32(( RW_SIZEADDR ),*(u32 *)&tmpbuf[0]);

	for(i=0;i<(len/4);i++)
	{
		wrReg32(( RW_DATA),*(u32 *)&data[i*4]);
	}
	if(len%4)
		wrReg32(( RW_DATA),*(u32 *)&data[i*4]);

	//command
	tmpbuf[0] = 0x00; 
	tmpbuf[1] = 0x00; 
	tmpbuf[2] = 0x00;	
	tmpbuf[3] = 0x00;
	wrReg32((COMMAND),*(u32 *)&tmpbuf[0]);
	
	tmpbuf[0] = 0x00; // when finish the write , set clear (bit31)to 0
	wrReg32((DATA_BLKCTRL),*(u32 *)&tmpbuf[0]);
	
	if(!check_status_ack())
		return 0;


	return 1;
}
//add load logo1.bmp support 
void send_file(int cmd,char*filename)
{       
	int offset=0;
	int len=0;
	int i=0;
        int packet_len=0;
        char str[10240+128]={0};
	int first_flag=0;
	FILE *fp=NULL;
	int ret=0;
	char buf[MAX_PACKET_LEN]={0};
	int remain_len=0;

	FILE *fpmd5;
	char md5str[64];
	char strcmd[64] = "md5sum ";
	strcat(strcmd,filename);
        printf("cmd: %s\n", strcmd); 
	fpmd5 = popen(strcmd,"r");

	int nread = fread(md5str,1,32,fpmd5);
	printf("read md5str %d byte, %s\n", nread,md5str);
	pclose(fpmd5);

	char *testfile_md5 = md5str;

        printf("--testfile_md5:%s\n",testfile_md5);
	
	fp=fopen(filename,"rb");
	if(!fp)
	{
		perror("fopen");
		return;
	}	
	
	ret=fseek(fp,0,SEEK_END);//定位到文件的最后面
	if(ret!=0)
		return;
 	len  = ftell(fp);
	printf("file len=%d\n",len);		

	ret=fseek(fp,0,SEEK_SET);
	if(ret!=0)
                return;

        if(len<=MAX_PACKET_LEN)
        {
		memset(buf,0,sizeof(buf));
		fread(buf,1,len,fp);
		fclose(fp);
		packet_len=len;

		memcpy(str+offset,testfile_md5,32);
		offset=offset+32;

                memcpy(str+offset,buf,len);
                printf("--- 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x 0x%x \n",str[0],str[1],str[2],str[3],str[4],str[5],str[6],str[7]);

		update_write(cmd, str,offset+len,packet_len);


        }
        else
        {
		for(i=0;i<len/MAX_PACKET_LEN;i++)
		{
			memset(buf,0,sizeof(buf));
			fread(buf,1,MAX_PACKET_LEN,fp);
			offset=0;
			if(first_flag == 0)
				packet_len=len;
			else
				packet_len=0;

			if(first_flag == 0)
			{
				memcpy(str+offset,testfile_md5,32);
				offset=offset+32;
			}
			memcpy(str+offset,buf,MAX_PACKET_LEN);
			update_write(cmd, str,offset+MAX_PACKET_LEN,packet_len);

			first_flag=1;
			usleep(1000);//10ms
		}	
		remain_len=len%MAX_PACKET_LEN;

		if(remain_len)
		{
			memset(buf,0,sizeof(buf));
                	fread(buf,1,remain_len,fp);
                
			offset=0;
			packet_len=0;
			memcpy(str+offset,buf,remain_len);
			update_write(cmd, str,offset+remain_len, packet_len);
			//printf("-send datelen=%d\n",remain_len);
			usleep(1000);//10ms
			
		}
		fclose(fp);
        }


}

void usage()
{
	printf("\n");
	printf("The version of the tool is V1.0.0.1\n");
 	printf("-a : <adapter>\n");
	//printf("-w : <enc_width: 0-3840, 0: auto(same to input width)>\n");
	//printf("-h : <enc_height: 0-2160, 0: auto(same to input height)>\n");
	printf("-s : <encoded size: 0(auto),1(640x360),2(640x480),3(704x576),4(720x480),5(720x576),6(1024x576),7(1280x720),8(1680x1056),9(1920x1080)>\n");
	printf("-f : <enc_fps: 5-60>\n");
 	printf("-e : <enc_type: H264 or H265>\n");
	printf("-l : <codec_type: cbr,vbr,evbr>\n");
	printf("-b : <cbr,vbr and evbr bitrate(Kbps): 160-20000>\n");
	printf("-t : <pmt,transpid,vpid,sid>: pmt(16-7936), transpid and vpid(16-3840)\n");
	printf("-N : <program_name> set the program Name at most 16 characters \n");

	printf("-k : <venc_gop: 1-180 (key interval under IPPP)>\n");
	printf("-q : <minQp: 5-48 (vbr and evbr)>\n");
	printf("-Q : <maxQp: minQp-51 (vbr and evbr)>\n");
	printf("-p : <H264 profile: 0:baseline, 1:main, 2:high; H265 profile: 1:main, supports main profile only>\n");

	printf("-T : <ts null packet: 0(off),2(1.2x),3,4,5,6,7,8,9,10(2.0x),12,14,16,18,20(3.0x)>\n");
	printf("-I : <audio bitrate(bps): 24000,32000,44100,48000,64000,96000,128000,160000,192000,256000> \n");
	printf("-A : <AAC type: LC-AAC, HE-AAC(Audio Bitrate should be in 24000-51000)>\n");
	printf("-J : <Audio Codec: 0:AAC, 1:MP2>\n");
	printf("-D : <audio resample: 0(off),44100,32000>\n");
	printf("-E : <TS buffer(188*n): 1,2,3,4,5,6,7>\n");
	printf("-U : <SDI Audio channel: 0(channel 1 2),1(channel 3 4),2(channel 5 6),3(channel 7 8)>\n");
	printf("-P : <Audio input: 0(SDI audio),1(Line in),2(Mixing audio)>(this parameter works for tbs6322 only, tbs6324 does not support Line in)\n");
	
	printf("-i : read SDI input informations:width,height,frame rate,audio sample rate \n");
	printf("-c : check Encoder configurations \n");
	printf("-r : reboot Encoder \n");
	printf("-R : reset Encoder: factory reset and reboot \n");
	printf("-v : check Encoder firmware version \n");
	printf("-g : update firmware\n");
	printf("-d : enumerate device list  \n");

	printf("-G : upload logo1.bmp(logo name & format: logo1.bmp; the width and height of logo must be multiples of 4. For example,64x64,100x64,128x128 and etc.; logo size less than 200KB)\n");
	printf("-L : <logo enable 0:off,1:on> \n");
	printf("-B : <logo alpha: 0(0%),1(25%),2(37.5%),3(50%),4(62.5%),5(75%),6(87.5%),7(100%)> \n");
	printf("-x : <x (logo x position)> \n");
	printf("-y : <y (logo y position)> \n");

	printf("-W : <font enable  0:off,1:on> \n");
	printf("-X : <x (font x position)> \n");
	printf("-Y : <y (font y position)> \n");
	printf("-S : <font size: 8-72> \n");
	printf("-H : <font alpha:0(0%),1(25%),2(37.5%),3(50%),4(62.5%),5(75%),6(87.5%),7(100%)> \n");
	printf("-C : <font color:0-0xffffffff (red:0xffff0000, green:0xff00ff00,blue:0xff0000ff)> \n");
	printf("-M : <Text:up to 255 character> \n");

	printf("\n");
	printf("\n");
	exit(1);
}   

static const struct option long_options[] =
{
	{ "tbsadapter", required_argument, NULL, 'a'},
	{0,0}
	
};
int main( int argc, char **argv)
{

	int c;
	char psz_tmp[128];
	FILE * r_file_fd;  
	FILE * w_file_fd;  
	int read_len ,i;
	u32 pid[5]={0};

	char str_pmt_id[8] = {0};
	char str_vid_id[8] = {0};
	char str_aud_id[8] = {0};
	char str_program_id[8] = {0};

	unsigned char tmpbuf[4] = {0};
    	char send_cmdstr[1024]={0};
	int send_cmdlen=0;

	char send_extstr[1024]={0};
	int send_extlen=0;

	char send_osdstr[1024]={0};
	int send_osdlen=0;

    	char recev_cmdstr[1024]={0};
	char out[256] = {0};
	int tmplen = 0;
	int ret = 0;

	
	if(argc ==1)
	{
		usage();
	}
	while ( (c = getopt_long(argc, argv, "a:w:h:s:f:T:p:e:b:k:t:iI:A:D:E:U:P:crRvgl:Q:q:N:dGL:B:x:y:W:X:Y:S:H:C:M:J:", long_options, NULL)) != -1 )     
	{
		switch ( c )
		{
			case 'a':
			i_adapterEN = 1;
			  i_adapterN = strtol( optarg, NULL, 0 );
			  break;
			case 'w':
			   	i_widthEN = 1;
				str_widthNum = optarg;
				tmplen = add_param_package_string("enc_width",str_widthNum,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}

			    	break;
			case 'h':
			   	i_heightEN = 1;
				str_heightNum = optarg;
				tmplen = add_param_package_string("enc_height",str_heightNum,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}

			    	break;

			case 's':

				i_sizeNum = strtol( optarg, NULL, 0 );
				if((i_sizeNum <0)||(i_sizeNum>13))
				{					
					printf("error para! Encoded size: 0-13\n");
					break;
				}
			   	i_sizeEN = 1;
				switch(i_sizeNum)
				{
					case 0:
					tmplen = add_param_package_string("enc_width","0",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","0",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}

					break;

					case 1:
					tmplen = add_param_package_string("enc_width","640",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","360",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}

					break;
	
					case 2:
					tmplen = add_param_package_string("enc_width","640",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","480",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}

					break;

					case 3:
					tmplen = add_param_package_string("enc_width","704",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","576",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}

					break;

					case 4:
					tmplen = add_param_package_string("enc_width","720",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","480",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}

					break;

					case 5:
					tmplen = add_param_package_string("enc_width","720",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","576",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}

					break;

					case 6:
					tmplen = add_param_package_string("enc_width","1024",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","576",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}

					break;

					case 7:
					tmplen = add_param_package_string("enc_width","1280",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","720",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					break;

					case 8:
					tmplen = add_param_package_string("enc_width","1680",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","1056",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					break;

					case 9:
					tmplen = add_param_package_string("enc_width","1920",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","1080",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					break;
					/*
					case 10:
					tmplen = add_param_package_string("enc_width","2048",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","1152",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					break;

					case 11:
					tmplen = add_param_package_string("enc_width","2560",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","1440",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					break;

					case 12:
					tmplen = add_param_package_string("enc_width","2560",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","1600",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					break;

					case 13:
					tmplen = add_param_package_string("enc_width","3840",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					tmplen = add_param_package_string("enc_height","2160",out);
					if(tmplen >0)
					{
						memcpy(send_cmdstr+send_cmdlen,out,tmplen);
						send_cmdlen+=tmplen;
					}
					break;*/
				}

			    	break;

			case 'f':

				i_fpsNum = strtol( optarg, NULL, 0 );
				if((i_fpsNum <5)||(i_fpsNum>60))
				{					
					printf("error para! encoding frame rate: 5-60\n");
					break;
				}

			   	i_fpsEN = 1;
				// to set the same value to h264 and h265 
				tmplen=add_param_package_string("h264_fps",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
				tmplen=add_param_package_string("h265_fps",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
			    	break;
			case 'p':

				i_profileNum = strtol( optarg, NULL, 0 );
				if((i_profileNum <0)||(i_profileNum>2))
				{					
					printf("error para! H264 profile: 0(baseline), 1(main), 2(high)\n");
					break;
				}

			   	i_profileEN = 1;
				tmplen=add_param_package_string("codec_profile",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
			    	break;
			case 'e':
				str_encodeMode = optarg;
				if((strcmp(str_encodeMode,"H264")!=0)&&(strcmp(str_encodeMode,"H265")!=0))
				{					
					printf("error para! encoding type: H264 or H265\n");
					break;
				}

			  	i_encodeModeEN = 1;
				tmplen=add_param_package_string("enc_type",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
			    	break;
			case 'b':
				i_bitrateNum = strtol( optarg, NULL, 0 );
				if((i_bitrateNum <160)||(i_bitrateNum>20000))
				{					
					printf("error para! cbr,vbr and evbr bitrate(k): 160-20000\n");
					break;
				}

				i_bitrateEN = 1;
				tmplen=add_param_package_string("cbr_rate",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
				tmplen=add_param_package_string("vbr_rate",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
				tmplen=add_param_package_string("evbr_rate",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
			    	break;
			case 'l':

				str_codecType = optarg;
				if((strcmp(str_codecType,"cbr")!=0)&&(strcmp(str_codecType,"vbr")!=0)&&(strcmp(str_codecType,"evbr")!=0))
				{					
					printf("error para! codec type: cbr,vbr,evbr\n");
					break;
				}



				i_codecTypeEN = 1;
				tmplen=add_param_package_string("codec_type",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
                		break;
            		case 'k':
				i_GopkeyNum = strtol( optarg, NULL, 0 );
				if((i_GopkeyNum <1)||(i_GopkeyNum>180))
				{					
					printf("error para! key interval: 1-180 \n");
					break;
				}

           			i_GopkeyEN = 1;
				tmplen=add_param_package_string("venc_gop",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}

				break;
			case 'q':
				i_minqpNum = strtol( optarg, NULL, 0 );
				if((i_minqpNum <5)||(i_minqpNum>48))
				{					
					printf("error para! minQp: 5-48 (vbr and evbr) \n");
					break;
				}

			   	i_minqpEN = 1;
				tmplen=add_param_package_string("minqp",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}

				tmplen=add_param_package_string("evbr_minqp",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
				break;
			case 'Q':

				i_maxqpNum = strtol( optarg, NULL, 0 );
				if((i_maxqpNum <5)||(i_maxqpNum>51))
				{					
					printf("error para! maxQp: minQp-51 (vbr and evbr) \n");
					break;
				}

				i_maxqpEN = 1;
				tmplen=add_param_package_string("maxqp",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
				tmplen=add_param_package_string("evbr_maxqp",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
                		break;
            		case 'T':
				i_nullPacketNum = strtol( optarg, NULL, 0 );
				if((i_nullPacketNum <0)||(i_nullPacketNum>20))
				{					
					printf("error para! TS null packet: 0,2,3,4,5,6,7,8,9,10,12,14,16,18,20\n");
					break;
				}

           			i_nullPacketEnableEN = 1;
				tmplen=add_param_package_string("ts_null",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_cmdstr+send_cmdlen,out,tmplen);
					send_cmdlen+=tmplen;
				}
				break;	

			case 't':
			
				sscanf( optarg, "%u,%u,%u,%u", &pid[0],&pid[1],&pid[2],&pid[3]);
				if((pid[0] <16)||(pid[0]>7936))
				{					
					printf("error para! pmt(16-7936)\n");
					break;
				}
				if((pid[1] <16)||(pid[1]>3840))
				{					
					printf("error para! transpid(16-3840)\n");
					break;
				}
				if((pid[2] <16)||(pid[2]>3840))
				{					
					printf("error para! vpid(16-3840)\n");
					break;
				}
				if((pid[3] <1)||(pid[3]>65535))
				{					
					printf("error para! sid(1-65535)\n");
					break;
				}
			i_pidEN = 1;
			sprintf(str_pmt_id, "%d",pid[0]);
			sprintf(str_vid_id, "%d",pid[1]);
			sprintf(str_aud_id, "%d",pid[2]);
			sprintf(str_program_id, "%d",pid[3]);

			printf("set <pmt,transpid,vpid,sid> to <%s,%s,%s,%s>\n",str_pmt_id,str_vid_id,str_aud_id,str_program_id);
			tmplen=add_param_package_string("pmt_id",str_pmt_id,out);
			if(tmplen >0)
			{
				memcpy(send_cmdstr+send_cmdlen,out,tmplen);
				send_cmdlen+=tmplen;
			}
			tmplen=add_param_package_string("vid_id",str_vid_id,out);
			if(tmplen >0)
			{
				memcpy(send_cmdstr+send_cmdlen,out,tmplen);
				send_cmdlen+=tmplen;
			}
			tmplen=add_param_package_string("aud_id",str_aud_id,out);
			if(tmplen >0)
			{
				memcpy(send_cmdstr+send_cmdlen,out,tmplen);
				send_cmdlen+=tmplen;
			}
			tmplen=add_param_package_string("program_id",str_program_id,out);
			if(tmplen >0)
			{
				memcpy(send_cmdstr+send_cmdlen,out,tmplen);
				send_cmdlen+=tmplen;
			}
			break;
		case 'N':
			i_prognameEN = 1;
			str_progname = optarg;

			unsigned char strname[17] = {0x00};

			if(strlen(str_progname)>16)
				memcpy(strname,str_progname, 16);
			else
				memcpy(strname,str_progname, strlen(str_progname));
			printf("set progname to: %s\n",strname);


			tmplen =add_param_package_string("program_name",strname,out);
			if(tmplen >0)
			{	
				memcpy(send_cmdstr+send_cmdlen,out,tmplen);
				send_cmdlen+=tmplen;
			}

		    break;
		case 'I':

			i_abNum = strtol( optarg, NULL, 0 );
			if((i_abNum !=24000)&&(i_abNum !=32000)&&(i_abNum !=44100)&&(i_abNum !=48000)&&(i_abNum !=64000)&&(i_abNum !=96000)&&(i_abNum !=128000)&&(i_abNum !=160000)&&(i_abNum !=192000)&&(i_abNum !=256000))
			{					
				printf("error para! audio bitrate: 24000,32000,44100,48000,64000,96000,128000,160000,192000,256000\n");
				break;
			}

		 	i_audiobitrateEN = 1;
			tmplen=add_param_package_string("a0_bitrate",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_extstr+send_extlen,out,tmplen);
				send_extlen+=tmplen;
			}
		break;
		case 'J':

			i_TSaudio =  strtol( optarg, NULL, 0 );
			if((i_TSaudio!=0)&&(i_TSaudio !=1))
			{					
				printf("error para! Audio Codec: 0:AAC, 1:MP2\n");
				break;
			}

		 	i_TSaudioEN = 1;
			tmplen=add_param_package_string("ts_audio",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_extstr+send_extlen,out,tmplen);
				send_extlen+=tmplen;
			}
		break;
		case 'A':

			str_audiotype = optarg;
			if((strcmp(str_audiotype,"LC-AAC")!=0)&&(strcmp(str_audiotype,"HE-AAC")!=0))
			{					
				printf("error para! AAC type: LC-AAC or HE-AAC\n");
				break;
			}

		 	i_audiotypeEN = 1;
			tmplen=add_param_package_string("aac_type",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_extstr+send_extlen,out,tmplen);
				send_extlen+=tmplen;
			}
		break;

		case 'D':

			i_aResampleNum = strtol( optarg, NULL, 0 );
			if((i_aResampleNum !=0)&&(i_aResampleNum != 44100)&&(i_aResampleNum != 32000))
			{					
				printf("error para! audio resample: 0(off),44100,32000 \n");
				break;
			}

		 	i_audioResampleEN = 1;
			tmplen=add_param_package_string("audio_resample",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_extstr+send_extlen,out,tmplen);
				send_extlen+=tmplen;
			}
		break;
		case 'E':
			i_TSbufferNum = strtol( optarg, NULL, 0 );
			if((i_TSbufferNum <1)||(i_TSbufferNum>7))
			{					
				printf("error para! TS buffer(188*n): 1,2,3,4,5,6,7 \n");
				break;
			}
		 	i_TSbufferEN = 1;
			tmplen=add_param_package_string("ts_buff",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_extstr+send_extlen,out,tmplen);
				send_extlen+=tmplen;
			}
		break;
		case 'U':
			i_audiochannelNum = strtol( optarg, NULL, 0 );
			if((i_audiochannelNum <0)||(i_audiochannelNum>3))
			{					
				printf("error para! Audio channel: 0(channel 1 2),1(channel 3 4),2(channel 5 6),3(channel 7 8) \n");
				break;
			}
		 	i_audiochannelEN = 1;
			tmplen=add_param_package_string("sdi_audio_channel",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_extstr+send_extlen,out,tmplen);
				send_extlen+=tmplen;
			}
		break;
		
		case 'P':

			i_audioinputNum = strtol( optarg, NULL, 0 );
			str_audioinputNum = optarg;
			if((i_audioinputNum <0)||(i_audioinputNum>2))
			{					
				printf("error para! Audio input: 0(SDI audio),1(Line in),2(Mixing audio) \n");
				break;
			}
		 	i_audioinputEN = 1;

		break;

		case 'r':
		  	i_softwareRST = 1;
		    	break; 
		case 'R':
		  	i_hardwareRST = 1;
		    	break; 
		case 'i':
		 	i_information = 1;
		    	break;

		case 'c':
		 	i_cfg = 1;
		    	break;
		case 'v':
		 	i_version = 1;
		   	 break;
		case 'g':
		  	i_system_update =1;
		    	break;

		case 'd':
		 	i_device_list = 1;
		    	break;
		case 'F':
		 	i_FPGA_EN = 1;
		    break;
		case 'G':
		  	i_logo_update =1;
		    	break;

		case 'L':

			i_logoenableNum = strtol( optarg, NULL, 0 );
			if((i_logoenableNum ==1)||(i_logoenableNum == 0))
			{					
			 	i_logoEN = 1;
				tmplen=add_param_package_string("logo_enable",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_osdstr+send_osdlen,out,tmplen);
					send_osdlen+=tmplen;
				}
			}
			else
			{
				printf("error para! logo enable 0:off,1:on\n");
			}
			break;
		case 'B':

			i_logoAlphaNum = strtol( optarg, NULL, 0 );
			if((i_logoAlphaNum <0)||(i_logoAlphaNum>7))
			{					
				printf("error para! logo alpha: 0(0%),1(25%),2(37.5%),3(50%),4(62.5%),5(75%),6(87.5%),7(100%)\n");
				break;
			}
			else
			{
				i_logoAlphaEN = 1;
				tmplen=add_param_package_string("logo_alpha",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_osdstr+send_osdlen,out,tmplen);
					send_osdlen+=tmplen;
				}
			}
			break;

		case 'x':
		  	i_logoXEN =1;
			tmplen=add_param_package_string("logo_x",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_osdstr+send_osdlen,out,tmplen);
				send_osdlen+=tmplen;
			}
		    	break;
		case 'y':
		  	i_logoYEN =1;
			tmplen=add_param_package_string("logo_y",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_osdstr+send_osdlen,out,tmplen);
				send_osdlen+=tmplen;
			}
		    	break;
		case 'W':
			i_txtenableNum = strtol( optarg, NULL, 0 );
			if((i_txtenableNum ==1)||(i_txtenableNum == 0))
			{					
			 	i_txtEN = 1;
				tmplen=add_param_package_string("txt_enable",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_osdstr+send_osdlen,out,tmplen);
					send_osdlen+=tmplen;
				}
			}
			else
			{
				printf("error para! txt enable 0:off,1:on\n");
			}
			break;
		case 'X':
		  	i_txtXEN =1;
			tmplen=add_param_package_string("txt_x",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_osdstr+send_osdlen,out,tmplen);
				send_osdlen+=tmplen;
			}
		    	break;
		case 'Y':
		  	i_txtYEN =1;
			tmplen=add_param_package_string("txt_y",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_osdstr+send_osdlen,out,tmplen);
				send_osdlen+=tmplen;
			}
		    	break;
		case 'S':
			i_txtSizeNum = strtol( optarg, NULL, 0 );
			if((i_txtSizeNum <8)||(i_txtSizeNum>72))
			{					
				printf("error para! font size:8-72\n");
				break;
			}
			else
			{
				i_txtSizeEN = 1;
				tmplen=add_param_package_string("txt_size",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_osdstr+send_osdlen,out,tmplen);
					send_osdlen+=tmplen;
				}
			}
			break;
		case 'H':

			i_txtAlphaNum = strtol( optarg, NULL, 0 );
			if((i_txtAlphaNum <0)||(i_txtAlphaNum>7))
			{					
				printf("error para! txt alpha: 0(0%),1(25%),2(37.5%),3(50%),4(62.5%),5(75%),6(87.5%),7(100%)\n");
				break;
			}
			else
			{
				i_txtAlphaEN = 1;
				tmplen=add_param_package_string("txt_alpha",optarg,out);
				if(tmplen >0)
				{
					memcpy(send_osdstr+send_osdlen,out,tmplen);
					send_osdlen+=tmplen;
				}
			}
			break;
		case 'C':
		  	i_txtcolorEN =1;
			tmplen=add_param_package_string("txt_color",optarg,out);
			if(tmplen >0)
			{
				memcpy(send_osdstr+send_osdlen,out,tmplen);
				send_osdlen+=tmplen;
			}
		    	break;

		case 'M':
			i_txtStrEN = 1;
			tmplen =add_param_package_string("txt_str",optarg,out);
			if(tmplen >0)
			{	
				memcpy(send_osdstr+send_osdlen,out,tmplen);
				send_osdlen+=tmplen;
			}

		    break;

		default:
		usage();
		break;	
		}
	}
  	if(optind < argc )
        usage();		
        
	getHardwareInfor();
	if(i_device_list ==1)
	{
		
		
		for(i =0; i< inforn;i++)
		{
			sprintf( psz_tmp, "/dev/dvb/adapter%d/frontend0",  hf[i].adapter_i );
		   	if( (i_frontend = open(psz_tmp, O_RDWR | O_NONBLOCK)) < 0 )
			{
				printf( "opening device %s failed (%s)\n", psz_tmp,strerror(errno) );
				// Still report what we can here
				printf("%d. %s Capture%d ,(adapter %d frontend 0) \n",
					   i,hf[i].devname,hf[i].hdmi_index,hf[i].adapter_i);
				continue;
			}
		
			*(u32 *)tmpbuf = gpio_rd( 0x28);
			printf("%d. %s(%x%x-%x-%x) Capture%d ,(adapture %d frontend 0) \n",
					   i,hf[i].devname,tmpbuf[0],tmpbuf[1],tmpbuf[2],tmpbuf[3],hf[i].hdmi_index,hf[i].adapter_i);

			close(i_frontend);
		}
		
	 return 0;
	}

	if(0 == inforn){
        printf("No valid devices is scanned!\n");
        return -1;
    	}

	if(0 == i_adapterEN){
		usage();
		return -1;
    	}
	for(i=0;i<inforn;i++)
	{
		if(i_adapterN==hf[i].adapter_i)	
		{	
			devnum = i;
			break;
		}

	}
	if(i==inforn)  //can't find i_adapterN in capture list
	{
		printf("adapter %d isn't supported\n",i_adapterN);
		return -1;
	}
	//printf("%s, inforn:%d, devnum:%d, i_adapterN:%d,i:%d\n", hf[devnum].devname, inforn,devnum, i_adapterN,i);
	if("TBS6304X"==hf[devnum].devname)
		typeId= TBS6304X_0 + hf[devnum].hdmi_index;
	else if("TBS6324"==hf[devnum].devname)
		typeId= TBS6324_0 + hf[devnum].hdmi_index;
	else if("TBS6322"==hf[devnum].devname)
		typeId= TBS6322_0 + hf[devnum].hdmi_index;
	else if("TBS6302X"==hf[devnum].devname)
		typeId= TBS6302X_0 + hf[devnum].hdmi_index;
	else if("TBS6302T"==hf[devnum].devname)
		typeId= TBS6302T_0 + hf[devnum].hdmi_index;
	else if("TBS6301T"==hf[devnum].devname)
		typeId= TBS6301T;
	else if("TBS6304T"==hf[devnum].devname)
		typeId= TBS6304T_0 + hf[devnum].hdmi_index;
	else if("TBS6308X"==hf[devnum].devname)
		typeId= TBS6308X_0 + hf[devnum].hdmi_index;
	else if("TBS6312X"==hf[devnum].devname)
		typeId= TBS6312X_0 + hf[devnum].hdmi_index;
	else
	{
		printf("the device can't be supported\n");
		typeId = 0;
		return -1;
	}
	if(i_audioinputEN == 1)
	{
		if(( typeId !=TBS6322_0)&&( typeId !=TBS6322_1))
		{
			printf("This card don't have line in interface. \n");
			return -1;
		}
		tmplen=add_param_package_string("a0_input",str_audioinputNum,out);
		if(tmplen >0)
		{
			memcpy(send_extstr+send_extlen,out,tmplen);
			send_extlen+=tmplen;
		}
	}
	sprintf( psz_tmp, "/dev/dvb/adapter%d/frontend0", i_adapterN );
	
	struct stat st;
	if(-1 == stat(psz_tmp,&st))
	{
		fprintf(stderr,"Cannot identify '%s':%d,%s\n",psz_tmp,errno,strerror(errno));
		exit(EXIT_FAILURE);
	}

	if(!S_ISCHR(st.st_mode))
	{
		fprintf(stderr,"%s is no device \n",psz_tmp);
		exit(EXIT_FAILURE);
	}

	if( (i_frontend = open(psz_tmp, O_WRONLY)) < 0 )
	{
		printf( "opening device %s failed (%s)", psz_tmp,strerror(errno) );
		exit(1);
	}
	printf( "opening device %s OK!\n\n", psz_tmp);
                                                                                                 
	if(i_version ==1)
	{
		//version id
		memset(recev_cmdstr,0,sizeof(recev_cmdstr));
		udp_read(GET_EXT,recev_cmdstr,600);
		//printf("\n%s\n",&recev_cmdstr[0]);

		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"version",out);
                if(ret == 0)
                {
			printf("version: %s\n\n",out);
		}

	}
	if(i_softwareRST ==1)
	{
		printf("Reboot system! please wait about 30s.\n");
		reboot();
	}
	if(i_hardwareRST ==1)
	{
		printf("restore to factory settings! \n");
		reset();
		reboot();

	}
	if(i_system_update ==1)
	{

		send_file(UPLOAD_FIMWARE,"./upgrade.bin");
		memset(recev_cmdstr,0,sizeof(recev_cmdstr));
		udp_read(UPLOAD_FIMWARE,recev_cmdstr,10);
		printf("\n%s\n",&recev_cmdstr[0]);

	}
	if(i_logo_update == 1)
	{
		struct stat fstat;
		stat("./logo1.bmp", &fstat);
		printf("logo1.bmp size: %d kB\n", fstat.st_size/1024);
		if((fstat.st_size/1024)>200)
		{
			printf("error para! logo1.bmp should less than 200kB\n");	
		}
		else
		{
			send_file(UPLOAD_BMP1,"./logo1.bmp");
			memset(recev_cmdstr,0,sizeof(recev_cmdstr));
			udp_read(UPLOAD_BMP1,recev_cmdstr,10);
			printf("\n%s\n",&recev_cmdstr[0]);
		}
	}

	if(i_information ==1)
	{
		unsigned char stream[4] = { 0 };
		*(u32 *)&stream[0] = rdBuf32(0x48);
		if(1 == (stream[2] & 0x01)) 
		{
			printf("Stream: ON\n");
		}
		else 
		{
			printf("Stream: OFF\n");
		}

		memset(recev_cmdstr,0,sizeof(recev_cmdstr));
		udp_read(GET_EXT,recev_cmdstr,1024);
		//printf("\n%s\n\n",&recev_cmdstr[0]);
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"hdmi_info",out);
                if(ret == 0)
                {
			printf("Video Info: %s\n",out);
			if(out[0]=='0')
				printf("Audio Sample: 0\n\n");
			else
				printf("Audio Sample: 48000\n\n");
		}

	}
	if(i_FPGA_EN == 1) 
	{
		unsigned char tmpbuf[4] = { 0 };
		tmpbuf[0] = 0x01;
		tmpbuf[1] = 0x00;
		tmpbuf[2] = 0x00;
		tmpbuf[3] = 0x00;
		wrReg32(0x40, *(u32 *)tmpbuf);
	}
	if(i_cfg == 1)
	{

		printf("configure information on channel:\n");

		memset(recev_cmdstr,0,sizeof(recev_cmdstr));
		udp_read(GET_STREAM1,recev_cmdstr,1024);
		//printf("\n%s\n",&recev_cmdstr[0]);
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"enc_width",out);
                if(ret == 0)
                {	
			if(out[0]=='0')
				printf("Encoded width: auto\n");
			else
				printf("Encoded width: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"enc_height",out);
                if(ret == 0)
                {
			if(out[0]=='0')
				printf("Encoded height: auto\n");
			else
				printf("Encoded height: %s\n",out);
		}

		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"enc_type",out);
                if(ret == 0)
                {
			printf("Encoding type: %s\n",out);
		}
		if(strcmp(out,"H264")==0)
		{
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"codec_profile",out);
		        if(ret == 0)
		        {
				//printf("H.264 Profile: %s\n",out);
				if(out[0]=='0')
					printf("H.264 Profile: Baseline\n");
				else if(out[0]=='1')
					printf("H.264 Profile: Main\n");
				else if(out[0]=='2')
					printf("H.264 Profile: High\n");
				else
					printf("error para!\n");
			}
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"h264_fps",out);
		        if(ret == 0)
		        {
				printf("Encoding frame rate: %s\n",out);
			}
		}
		else if(strcmp(out,"H265")==0)
		{
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"h265_fps",out);
		        if(ret == 0)
		        {
				printf("Encoding frame rate: %s\n",out);
			}
		}
		else
		{
			printf("error para 001!\n");
		}

		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"codec_type",out);
                if(ret == 0)
                {
			printf("Bitrate control: %s\n",out);
		}
		if(strcmp(out,"cbr")==0)
		{
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"cbr_rate",out);
		        if(ret == 0)
		        {
				printf("cbr Bitrate(K): %s\n",out);
			}
		}
		else if(strcmp(out,"vbr")==0)
		{
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"vbr_rate",out);
		        if(ret == 0)
		        {
				printf("MaxBitrate(K): %s\n",out);
			}
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"minqp",out);
		        if(ret == 0)
		        {
				printf("MinQP: %s\n",out);
			}
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"maxqp",out);
		        if(ret == 0)
		        {
				printf("MaxQp: %s\n",out);
			}
		}
		else if(strcmp(out,"evbr")==0)
		{
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"evbr_rate",out);
		        if(ret == 0)
		        {
				printf("MaxBitrate(K): %s\n",out);
			}
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"evbr_minqp",out);
		        if(ret == 0)
		        {
				printf("MinQP: %s\n",out);
			}
			memset(out,0,sizeof(out));
		        ret=get_param(&recev_cmdstr[0],"evbr_maxqp",out);
		        if(ret == 0)
		        {
				printf("MaxQp: %s\n",out);
			}
		}	
		else
		{
			printf("error para! 002\n");
		}

		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"venc_gop",out);
                if(ret == 0)
                {
			printf("Key interval: %s\n",out);
		}

		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"pmt_id",out);
                if(ret == 0)
                {
			printf("PMT pid: %s\n",out);
		}

		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"vid_id",out);
                if(ret == 0)
                {
			printf("Transport ID: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"aud_id",out);
                if(ret == 0)
                {
			printf("Video ID: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"program_id",out);
                if(ret == 0)
                {
			printf("Program ID: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"program_name",out);
                if(ret == 0)
                {
			printf("Program name: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"ts_null",out);
                if(ret == 0)
                {
			printf("TS Null Packet: %s\n",out);
		}

		memset(recev_cmdstr,0,sizeof(recev_cmdstr));
		udp_read(GET_EXT,recev_cmdstr,1024);
		//printf("\n%s\n",&recev_cmdstr[0]);

		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"sdi_audio_channel",out);
                if(ret == 0)
                {
			//printf("sdi_audio_channel: %s\n",out);
			if(out[0]=='0')
				printf("sdi_audio_channel: channel 1 2\n");
			else if(out[0]=='1')
				printf("sdi_audio_channel: channel 3 4\n");
			else if(out[0]=='2')
				printf("sdi_audio_channel: channel 5 6\n");
			else if(out[0]=='3')
				printf("sdi_audio_channel: channel 7 8\n");
			else
				printf("error para!\n");
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"a0_input",out);
                if(ret == 0)
                {
			//printf("a0_input: %s\n",out);
			if(out[0]=='0')
				printf("Audio input: SDI audio\n");
			else if(out[0]=='1')
				printf("Audio input: Line in\n");
			else if(out[0]=='2')
				printf("Audio input: Mixing audio\n");
			else
				printf("error para!\n");
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"ts_audio",out);
                if(ret == 0)
                {
			//printf("ts_audio: %s\n",out);
			if(out[0]=='0')
				printf("Audio Codec: AAC\n");
			else if(out[0]=='1')
				printf("Audio Codec: MP2\n");
			else
				printf("error para!\n");
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"a0_bitrate",out);
                if(ret == 0)
                {
			printf("Audio bitrate: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"aac_type",out);
                if(ret == 0)
                {
			printf("AAC type: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"audio_resample",out);
                if(ret == 0)
                {
			printf("Audio resample: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"ts_buff",out);
                if(ret == 0)
                {
			printf("TS buffer: 188x%s\n",out);
		}

		//osd informations
		udp_read(GET_OSD1,recev_cmdstr,1024);
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"logo_enable",out);
                if(ret == 0)
                {
			printf("Logo enable: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"logo_x",out);
                if(ret == 0)
                {
			printf("Logo X: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"logo_y",out);
                if(ret == 0)
                {
			printf("Logo Y: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"logo_alpha",out);
                if(ret == 0)
                {
			printf("Logo Alpha: %s\n",out);
		}
		//font
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"txt_enable",out);
                if(ret == 0)
                {
			printf("Font enable: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"txt_x",out);
                if(ret == 0)
                {
			printf("Font X: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"txt_y",out);
                if(ret == 0)
                {
			printf("Font Y: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"txt_alpha",out);
                if(ret == 0)
                {
			printf("Font Alpha: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"txt_size",out);
                if(ret == 0)
                {
			printf("Font Size: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"txt_color",out);
                if(ret == 0)
                {
			printf("Font Color: %s\n",out);
		}
		memset(out,0,sizeof(out));
                ret=get_param(&recev_cmdstr[0],"txt_str",out);
                if(ret == 0)
                {
			printf("Text: %s\n\n",out);
		}
	}

	if((i_widthEN == 1)||(i_heightEN == 1)||(i_fpsEN == 1)||(i_sizeEN == 1)||(i_profileEN == 1)||(i_pidEN == 1)||(i_codecTypeEN == 1)||(i_encodeModeEN == 1)||(i_bitrateEN == 1)||(i_maxqpEN == 1)||(i_bitrateMaxEN == 1)||(i_minqpEN == 1)||(i_GopkeyEN == 1)||(i_nullPacketEnableEN == 1)||(i_prognameEN == 1))
	{
		//printf("send: %s\n",send_cmdstr);
		udp_write(SET_STREAM1, send_cmdstr, send_cmdlen);
		
	}
	if((i_audiobitrateEN == 1)||(i_audiotypeEN == 1)||(i_TSaudioEN ==1)||(i_audioResampleEN == 1)||(i_TSbufferEN == 1)||(i_audiochannelEN == 1)||(i_audioinputEN == 1))
	{
		//printf("sendext: %s\n",send_extstr);
		udp_write(SET_EXT, send_extstr, send_extlen);
		
	}
	
	if((i_logoEN == 1)||(i_logoAlphaEN == 1)||(i_logoXEN == 1)||(i_logoYEN == 1)||(i_txtEN == 1)||(i_txtXEN == 1)||(i_txtYEN == 1)||(i_txtAlphaEN == 1)||(i_txtcolorEN == 1)||(i_txtSizeEN == 1)||(i_txtStrEN == 1))
	{
		//printf("\n%s\n\n",&send_osdstr[0]);
		udp_write(SET_OSD1, send_osdstr, send_osdlen);
		
	}

	if(i_frontend >2)
	{
		close(i_frontend);
	}
	return 0;
}


