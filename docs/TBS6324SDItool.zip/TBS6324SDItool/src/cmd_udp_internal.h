#ifndef __UDP_INTERNAL_H__
#define __UDP_INTERNAL_H__


#ifdef __cplusplus
extern "C" {
#endif

#include "frontend.h"


#define BASE_ADDRESS_UDPCMD  	0x2000
#define COMMAND  	0x00   
#define STATUS  	0x00 
#define SERVICE_ID  	0x34  
#define RW_SIZEADDR  	0x08  
#define RW_TYPEADDR 	0x0c   
#define RW_LENADDR  	0x10    
#define RW_ADDRESS	0x0c   
#define RW_DATA  	0x18  
#define DATA_BLKCTRL  	0x14   

#define POLLING_TIMER  		6*4   
#define DIRECT_ADDRTIMER  	7*4  
#define INDIRECT_ADDRTIMER  8*4  
#define HL_SWAP  	9*4   
#define CMD_PORT  	10*4  
#define DATA_PORT  	11*4  

typedef unsigned char u8;
typedef unsigned int u32; 

typedef struct hf{
    int adapter_i;
    int frontend_i;
    u8 chipid[4];
    u8 chip2id[4];
    char bus_addr[17];
    char *devname;
    int hdmi_index;
} hardinfor;

#define TBSNULL            	0
#define TBS6301T            	1

#define TBS6302X_0            	2
#define TBS6302X_1            	3

#define TBS6302T_0            	4
#define TBS6302T_1            	5

#define TBS6304X_0            	6
#define TBS6304X_1            	7
#define TBS6304X_2            	8
#define TBS6304X_3            	9

#define TBS6304T_0            	10
#define TBS6304T_1            	11
#define TBS6304T_2            	12
#define TBS6304T_3            	13

#define TBS6308X_0            	14
#define TBS6308X_1            	15
#define TBS6308X_2            	16
#define TBS6308X_3            	17
#define TBS6308X_4            	18
#define TBS6308X_5            	19
#define TBS6308X_6            	20
#define TBS6308X_7            	21

#define TBS6312X_0            	22
#define TBS6312X_1            	23
#define TBS6312X_2            	24
#define TBS6312X_3            	25
#define TBS6312X_4            	26
#define TBS6312X_5            	27
#define TBS6312X_6            	28
#define TBS6312X_7            	29
#define TBS6312X_8           	30
#define TBS6312X_9            	31
#define TBS6312X_10            	32
#define TBS6312X_11           	33

#define TBS6324_0            	34
#define TBS6324_1            	35
#define TBS6324_2            	36
#define TBS6324_3            	37

#define TBS6322_0            	38
#define TBS6322_1            	39

#ifdef __cplusplus
}
#endif



#endif

