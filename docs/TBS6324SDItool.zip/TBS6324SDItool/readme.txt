﻿
-a <adapter>
-s : <encoded size: 0(auto),1(640x360),2(640x480),3(704x576),4(720x480),5(720x576),6(1024x576),
			7(1280x720),8(1680x1056),9(1920x1080)>
-f : <enc_fps: 5-60>
-e : <enc_type: H264 or H265>
-l : <codec_type: cbr,vbr,evbr>
-b : <cbr,vbr and evbr bitrate: 160-20000>
-t : <pmt,transpid,vpid,sid>: pmt(16-7936), transpid and vpid(16-3840)
-N : <program_name> set the program Name at most 16 characters
-k : <venc_gop: 1-180 (key interval under IPPP)>
-q : <minQp: 5-48 (vbr and evbr)>
-Q : <maxQp: minQp-51 (vbr and evbr)>
-p : <H264 profile: 0:baseline , 1: main, 2:high>
-T : <ts null packet: 0(off),2(1.2x),3,4,5,6,7,8,9,10(2.0x),12,14,16,18,20(3.0x)>

-I : <audio bitrate: 24000,32000,44100,48000,64000,96000,128000,160000,192000,256000>
-A : <AAC type: LC-AAC, HE-AAC(Audio Bitrate should be in 24000-51000)>
-J : <Audio Codec: 0:AAC, 1:MP2>
-D : <audio resample: 0(off),44100,32000>
-E : <TS buffer(188*n): 1,2,3,4,5,6,7>
-U : <SDI Audio channel: 0(channel 1 2),1(channel 3 4),1(channel 5 6),1(channel 7 8)>
-P : <Audio input: 0(SDI audio),1(Line in),2(Mixing audio)> (only for tbs6322)

-i : read sdi information:w,h,fps,audio_sample
-c : get the configures
-r : Reboot
-R : reset: restore to factory settings
-v : get the version
-g : system update

-d : enumerate device list 

-G : upload logo1.bmp
-L : <logo enable 0:off,1:on> 
-B : <logo alpha: 0(0%),1(25%),2(37.5%),3(50%),4(62.5%),5(75%),6(87.5%),7(100%)>
-x : <x (logo x position)> 
-y : <y (logo y position)>


-W : <font enable  0:off,1:on> 
-X : <x (font x position)> 
-Y : <y (font y position)> 
-S : <font size: 8-72> 
-H : <font alpha: 0(0%),1(25%),2(37.5%),3(50%),4(62.5%),5(75%),6(87.5%),7(100%)>   
-C : <font color:0-0xffffffff (red:0xffff0000, green:0xff00ff00,blue:0xff0000ff)> 
-M : <Text:up to 255 character>

examples：
1.check SDI input information:
# ./TBS6324SDITool -a 0 -i

2.set output of encode frame rate to 60 and size to 1920x1080  
# ./TBS6324SDITool -a 0 -f 60 -s 9 

3.set encode type to H264

# ./TBS6324SDITool -a 0 -e H264 

4.set encode bitrate control to cbr and bitrate to 10M

# ./TBS6324SDITool -a 0 -l cbr -b 10000 

5.set program name to mytv
# ./TBS6324SDITool -a 0 -N mytv

6.set the pids(pmt,transpid,vpid,sid) to 1024,768,512,256
# ./TBS6324SDITool -a 0 -t 1024,768,512,256

7.check the latest configuration
# ./TBS6324SDITool -a 0 -c

8. Reboot system
# ./TBS6324SDITool -a 0 -r

9. get nt98331 system version
# ./TBS6324SDITool -a 0 -v

10. set output audio bitrate to 128000 and AAC type to LC 
# ./TBS6324SDITool -a 0 -I 128000 -A LC-AAC

11. set audio resample to off 
# ./TBS6324SDITool -a 0 -D 0

12. set audio resample to 44100
# ./TBS6324SDITool -a 0 -D 44100

13. set Key interval to 30
# ./TBS6324SDITool -a 0 -k 30

14. set H264 profile to Main profile
# ./TBS6324SDITool -a 0 -p 1

15. upload logo1.bmp( The width and height of logo must be multiples of 4. For example,64x64,100x64,128x128 and etc. )
# ./TBS6324SDITool -a 0 -G

16. set logo and font
# ./TBS6324SDITool -a 0 -L 1 -B 7 -x 100 -y 100 -W 1 -X 100 -Y 200 -S 60 -H 7 -C 0xff00ff00 -M "hello TBS"

17. set Audio codec to MP2
# ./TBS6324SDITool -a 0 -J 1

default:
./TBS6324SDITool -a 0 -e H264 -b 10 -N SDI-A -l cbr -t 1024,768,512,256







